new DataTable('#menukasir');

new DataTable('#report');
  
